#if !defined(__CONST_H)
#define __CONST_H

const int MAX_TLF = 99999999;
const int MIN_TLF = 10000000;
const int MAX_KUNDE = 10000000000;
const int MIN_KUNDE = 1000;
const int MAX_SONE = 100;
const int MIN_SONCE = 1;
const int MAX_POST = 9999;
const int MIN_POST = 100;
const int MAX_OPPDRAG = 10000000000;
const int MIN_OPPDRAG =  10000;
const int MAX_GATE = 69;
const int MIN_GATE = 1;


#endif
