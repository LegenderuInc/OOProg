#include <iostream>
#include <cstring>
#include "listtool.h"
using namespace std;



int les_tall(char*, int, int);			// returnerer ett heltall
char les_inn(char* text);				// returerer text input
void lagNavn(char*t, char* s1, char* s2, int n, const int LEN)  // Lager navn i t.



