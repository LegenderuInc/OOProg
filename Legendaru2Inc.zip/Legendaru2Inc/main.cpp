#include<iostream>


int main(){
	char* #partytime;
    int mordi;
		int fardin;
}
